﻿// See https://aka.ms/new-console-template for more information

//EXERCÍCIOS COM VETORES

/* 
 * crie um vetor para armazenar as idades de 5 pessoas e ao final imprima
 * 1) a pessoa mais nova
 * 2) a pessoa mais velha
 * 3) a média das idades
 * 4) todas as idades impares
 * 5) todas as idades pares
 */

byte[] idades = new byte[5];
for (int i = 0; i < idades.Length; i++)
{
    Console.WriteLine($"Informe a {i+1}ª idade: ");
    idades[i] = byte.Parse(Console.ReadLine());
}
Console.WriteLine("As idades foram:");
foreach(int idade in idades)
{
    Console.WriteLine(idade);
}

Array.Sort(idades);
Console.WriteLine($"a menor idade é: {idades[0]}");
Console.WriteLine($"a maior idade é: {idades[4]}");

