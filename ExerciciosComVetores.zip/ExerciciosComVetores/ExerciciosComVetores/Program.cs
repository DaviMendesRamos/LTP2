﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

int[] idades = { 12, 50, 76, 45, 24 };
int media = idades[1]+idades[2]+idades[3]+idades[4]+idades[5]/5;
Array.Sort(idades);
Console.WriteLine(idades[1]);
Console.WriteLine(idades[5]);
